package example.usersgui;

public class AddAccount
{
     protected String FullName;
     protected String UserName;
     protected String Password;
    public AddAccount(String FirstName, String LastName, String UserName, String Password)
    {
        this.FullName = FirstName + " " + LastName;
        this.UserName = UserName;
        this.Password = Password;
    }
}
