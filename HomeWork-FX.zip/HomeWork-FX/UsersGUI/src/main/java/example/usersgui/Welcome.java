package example.usersgui;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class Welcome {
    String Name;
    String User;
    @FXML
    private Label Name_lbl;
    @FXML
    private Label UserName_lbl;
    void SetData(String Name, String User){
        this.Name = Name;
        this.User = User;
    }
    void initialize(){
         Name_lbl.setText(Name_lbl.getText()+""+Name);
         UserName_lbl.setText(UserName_lbl.getText()+""+User);
    }
}
