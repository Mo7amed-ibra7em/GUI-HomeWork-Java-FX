package example.usersgui;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;

import static example.usersgui.Main.Accounts;
import static example.usersgui.Main.Notification;
public class logIn {
    String Name ,User;
    @FXML
    private Label Notification_txt;
    @FXML
    private TextField Password_txt;
    @FXML
    private TextField UserName_txt;
    @FXML
    void OnClickSignUp(ActionEvent event) throws IOException {
        Parent SingUpPage = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("SignUp.fxml")));
        Scene HomeScene = new Scene(SingUpPage);
        Stage HomeStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        HomeStage.setResizable(false);
        HomeStage.setScene(HomeScene);
        HomeStage.centerOnScreen();
        HomeStage.show();
    }
    boolean IsEmpty(){
        return UserName_txt.getText().isEmpty() || Password_txt.getText().isEmpty();
    }
    boolean IsExisting(String UserName ,String Password){
        for (AddAccount Account : Accounts) {
            if (Account.UserName.equals(UserName) && Account.Password.equals(Password)) {
                User = Account.UserName;
                Name = Account.FullName;
                return true;
            }
        }
        return false;
    }
    @FXML
    void OnClickLogIn(ActionEvent event) throws IOException {
        if (!IsEmpty()) {
            if (IsExisting(UserName_txt.getText(), Password_txt.getText())) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Welcome.fxml"));
                Parent welcomePage = loader.load();
                Scene welcomeScene = new Scene(welcomePage);
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setResizable(false);
                stage.setScene(welcomeScene);
                stage.centerOnScreen();
                stage.show();
                Welcome welcomeCon = loader.getController();
                welcomeCon.SetData(Name,User);
                welcomeCon.initialize();
            } else {
                UserName_txt.setText("");
                Password_txt.setText("");
                Notification(Notification_txt, "Account not found ...", Color.web("#E42721"));
            }
        } else {
            Notification(Notification_txt, "Enter all data ...", Color.web("#E42721"));
        }
    }
}
