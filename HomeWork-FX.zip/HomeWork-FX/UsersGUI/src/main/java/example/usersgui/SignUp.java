package example.usersgui;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.util.Objects;

import static example.usersgui.Main.Accounts;
import static example.usersgui.Main.Notification;

public class SignUp {
    @FXML
    private TextField FirstName_txt;
    @FXML
    private TextField LastName_txt;
    @FXML
    private Label Notification_txt;
    @FXML
    private TextField Password_txt;
    @FXML
    private TextField UserName_txt;
    @FXML
    public void OnClickLabelHaveAccount(MouseEvent event) throws Exception {
        Parent SingUpPage = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("LogIn.fxml")));
        Scene HomeScene = new Scene(SingUpPage);
        Stage HomeStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        HomeStage.setResizable(false);
        HomeStage.setScene(HomeScene);
        HomeStage.centerOnScreen();
        HomeStage.show();
    }
    @FXML
    public void OnClickSignUp() {IsEmpty();}
    boolean IsExisting(String User){
        for (AddAccount Account : Accounts) {
            if (Account.UserName.equals(User)) {
                return true;
            }
        }
        return false;
    }
    void IsEmpty(){
        if (!FirstName_txt.getText().isEmpty() && !LastName_txt.getText().isEmpty()
                && !UserName_txt.getText().isEmpty() && !Password_txt.getText().isEmpty()) {
            if (IsExisting(UserName_txt.getText())){
                Notification(Notification_txt,"The Account Already Exists ...", Color.web("#E42721"));
            } else {
                Accounts.add(new AddAccount(FirstName_txt.getText(), LastName_txt.getText(),
                        UserName_txt.getText(), Password_txt.getText()));

                FirstName_txt.setText("");
                LastName_txt.setText("");
                UserName_txt.setText("");
                Password_txt.setText("");
                Notification(Notification_txt,"Account Successfully Created ...", Color.web("#007A41FF"));
            }
        } else {
            Notification(Notification_txt,"Enter all data ...", Color.web("#E42721"));
        }
    }
}
