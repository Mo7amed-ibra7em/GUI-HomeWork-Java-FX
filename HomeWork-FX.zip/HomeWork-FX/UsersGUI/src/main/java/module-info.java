module example.usersgui {
    requires javafx.controls;
    requires javafx.fxml;


    opens example.usersgui to javafx.fxml;
    exports example.usersgui;
}