module example.carsgui {
    requires javafx.controls;
    requires javafx.fxml;


    opens example.carsgui to javafx.fxml;
    exports example.carsgui;
}