package example.carsgui;

public class AddCar {
    String Name;
    String Year;
    String Color;
    AddCar(String Name, String Year, String Color) {
        this.Name = Name;
        this.Color = Color;
        this.Year = Year;
    }
}
