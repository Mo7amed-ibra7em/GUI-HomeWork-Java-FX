package example.carsgui;

import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.ArrayList;

public class Cars {
    @FXML
    private TextField Color_txt;
    @FXML
    private Label CountCar_lbl;
    @FXML
    private Label DataCar_lbl;
    @FXML
    private TextField Name_txt;
    @FXML
    private TextField Year_txt;

    ArrayList<AddCar> ArrayCars = new ArrayList<>();
    @FXML
    public void OnClickAddCar(ActionEvent event) {
        if (!IsEmpty())
        {
            ArrayCars.add(new AddCar(Name_txt.getText(),Year_txt.getText(),Color_txt.getText()));
            Clean();
            ShowDataCars();
        }
    }
    boolean IsEmpty()
    {
        if(!Name_txt.getText().isEmpty() && !Color_txt.getText().isEmpty() && !Year_txt.getText().isEmpty())
        {
            return false;
        }
        return true;
    }
    void Clean()
    {
        Name_txt.setText("");
        Color_txt.setText("");
        Year_txt.setText("");
    }
    void ShowDataCars(){
        CountCar_lbl.setText("Count Car : "+ ArrayCars.size());
        int i = 0;
        String Data = "";
        for(AddCar Car : ArrayCars)
        {
            i++;
            Data = Data + "Data Car - "+i+" : Name :"+Car.Name+" - Year :"+Car.Year+" - Color :"+Car.Color+"\n";
        }
            DataCar_lbl.setText(Data);
    }
}