module example.pizzagui {
    requires javafx.controls;
    requires javafx.fxml;


    opens example.pizzagui to javafx.fxml;
    exports example.pizzagui;
}