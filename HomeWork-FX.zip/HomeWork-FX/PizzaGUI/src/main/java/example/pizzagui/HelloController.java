package example.pizzagui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;

public class HelloController {
    @FXML
    private CheckBox Corn_Check;
    @FXML
    private CheckBox Mushroom_Check;
    @FXML
    private TextField Name_txt;
    @FXML
    private CheckBox Olives_Check;
    @FXML
    private TextField Phone_txt;
    @FXML
    private CheckBox Sausage_Check;
    @FXML
    private RadioButton Thick_Radio;
    @FXML
    private RadioButton Thin_Radio;
    @FXML
    void SendOrder(ActionEvent event) throws IOException {
        Parent sendOrderPage = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Order.fxml")));
        Stage sendOrderStage = new Stage();
        Scene sendOrderScene = new Scene(sendOrderPage);
        sendOrderStage.setScene(sendOrderScene);
        sendOrderStage.initOwner(((Node) event.getSource()).getScene().getWindow());
        sendOrderStage.show();
    }
    @FXML
    void ClearOrder(ActionEvent event)
    {
        Name_txt.setText("");
        Phone_txt.setText("");
        Thick_Radio.setSelected(true);
        Thin_Radio.setSelected(false);
        Olives_Check.setSelected(false);
        Mushroom_Check.setSelected(false);
        Corn_Check.setSelected(false);
        Sausage_Check.setSelected(false);
    }
}